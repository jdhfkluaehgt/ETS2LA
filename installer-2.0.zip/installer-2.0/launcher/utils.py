import requests

def can_access_github():
    try:
        response = requests.get("https://github.com", timeout=5) # Short timeout
        response.raise_for_status() # Check for HTTP errors
        return True
    except requests.exceptions.RequestException:
        return False
    
# Convert a package name to a readable name that (hopefully) matches the package name.
def get_readable_name(module: str):
    delimiters = [".", " ", "=", ">", "<", "!", "?", ":", ";", "{", "}", 
                  "[", "]", "(", ")", "|", "&", "*", "^", "%", "$", "#", "@", "~", 
                  "`", "'", '"']
    index = 0
    for char in module:
        if char in delimiters or char.isdigit():
            index = module.index(char)
            break
        
    if index == 0:
        return module
        
    name = module[:index]
    if name[-1] == "-" or name[-1] == "_":
        name = name[:-1]
        
    return name

# Match a package name to a line in the requirements file to get the progress.
def get_index(lines: list[str], target: str):
    index = 0
    for line in lines:
        test_target = target.replace("-", "_")
        if test_target.lower() in line.lower() or test_target.lower() == line.lower():
            return index
        
        test_target = target.replace("_", "-")
        if test_target.lower() in line.lower() or test_target.lower() == line.lower():
            return index
        index += 1
    return -1