**Installing Requirements**
We are currently installing the required dependencies for ETS2LA. Please do not close the app during this process.