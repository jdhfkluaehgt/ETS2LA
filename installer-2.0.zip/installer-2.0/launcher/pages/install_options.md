**Installation Options**
Please make sure that you read the below information carefully before proceeding with the installation! You can hover over an option to see more information about it.