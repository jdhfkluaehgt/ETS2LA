**Notice about scams!**
If you have paid for **access, downloads or tutorials** for this application you have been **scammed**. ETS2LA is free and open source software, no payment required. We (the real developers) do not see any of this money.
\
关于诈骗的通知！
如果你付费购买了软件本体或使用教程，你已经被骗了！ETS2LA是免费的开源软件，不需要支付任何费用！我们（真正的开发人员）没有也无法从中获取任何收益。