**Welcome back!**
You can press the button below to start the app, or open the settings menu for additional startup options. Happy trucking!